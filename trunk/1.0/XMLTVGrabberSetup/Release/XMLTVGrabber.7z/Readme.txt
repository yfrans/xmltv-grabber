XMLTVGrabber Readme
-------------------

Available arguments:
XMLTVGrabberWin.exe [show_window] [# of days] [output file]

Default # of days: 1
Default output file: $ProgramDir$\xmltv.xml

For example:
Default # of days, default output file:	XMLTVGrabberWin.exe false
5 days, default output file:		XMLTVGrabberWin.exe false 5
default # of days, custom output file:	XMLTVGrabberWin.exe false "C:\MyGuide.xml"
5 days, custom output file:		XMLTVGrabberWin.exe false 5 "C:\MyGuide.xml"

Bugs, comments etc. - yfrans@gmail.com

Yossi Frances.